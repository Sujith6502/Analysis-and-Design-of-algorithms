#include<stdio.h>
int main(){
    int a[100],i,n,target,low,high,mid,flag=0;
    printf("Enter the value of n\n");
    scanf("%d",&n);
    printf("Enter the elements in the array\n");
    for(i=0;i<n;i++){
        scanf("%d",&a[i]);
    }
    printf("Enter the element to be searched\n");
    scanf("%d",&target);
    low=0;
    high=n-1;
    while(high>=low){
        mid=(low+high)/2;
        if(a[mid]==target){
            flag=1;
            printf("Element found at %d\n",mid);
            break;
        }
        else if(a[mid]<target){
            low=mid+1;
    
    }
    return 0;
    
}

