#include<stdio.h>
int main(){
    int a[100],i,n,target,flag=0;
    printf("Enter the value of n\n");
    scanf("%d",&n);
    printf("Enter the elements to be inserted\n");
    for(i=0;i<n;i++){
        scanf("%d",&a[i]);
    }
    printf("Enter the element to be searched\n");
    scanf("%d",&target);
    for(i=0;i<n;i++){
        if(a[i]==target){
            flag=1;
            printf("Element found");
        }
        printf("\n");
    }
    if(flag==0){
        printf("Element Not Found\n");
    }
    return 0;
    
}