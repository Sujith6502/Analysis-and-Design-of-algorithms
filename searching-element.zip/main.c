#include<stdio.h>
int main(){
    int i,n,a[100],target,flag=0;
    printf("Enter the value od n\n");
    scanf("%d",&n);
    for(i=0;i<n;i++){
        scanf("%d",&a[i]);
    }
    printf("Enter the value of target\n");
    scanf("%d",&target);
    for(i=0;i<n;i++){
        if(a[i]==target){
            flag=1;
            printf("Element found\n");
        }
    }
    if(flag==0){
        printf("Element not found\n");
    }
}